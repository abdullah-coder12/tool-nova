# ToolNova

A responsive, dark premium website with six client-side tools:
- Word Counter
- Case Converter
- Character Counter
- Percentage Calculator
- Age Calculator
- Password Generator

## Run locally
Open `index.html` in a modern browser. No build step or dependencies are required.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new **public** repository named `toolnova`.
2. Upload `index.html`, `style.css`, and `script.js` to the repository root (not inside another folder).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to finish deploying. Your site should be at `https://YOUR-USERNAME.github.io/toolnova/`.
7. Replace `YOUR-USERNAME` with your GitHub username. If you already have a repository named `toolnova`, choose a different repository name and use that name in the URL.

## Notes
- The tools run in the browser; the text tools do not send entered text to a server.
- Google Fonts is optional; the site has generic font fallbacks.
- Publishing is free, but traffic and income are not guaranteed. Advertising networks have eligibility and approval requirements; check their current policies before applying.
- Consider adding a privacy page and contact details before monetization. Do not add fake reviews or misleading claims.
