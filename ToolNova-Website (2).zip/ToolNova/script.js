const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const grid = $("#toolGrid");
const search = $("#toolSearch");
const workspace = $("#workspace");
const workspaceTitle = $("#workspaceTitle");
const workspaceContent = $("#workspaceContent");
const toast = $("#toast");
let toastTimer;

$("#year").textContent = new Date().getFullYear();

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}

function filterTools() {
  const term = search.value.trim().toLowerCase();
  let visible = 0;
  $$(".tool-card", grid).forEach(card => {
    const matches = (card.dataset.search + " " + card.innerText).toLowerCase().includes(term);
    card.hidden = !matches;
    if (matches) visible++;
  });
  $("#emptyState").hidden = visible !== 0;
  $("#toolCount").textContent = visible;
}
search.addEventListener("input", filterTools);
document.addEventListener("keydown", event => {
  if (event.key === "/" && !["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName)) {
    event.preventDefault(); search.focus();
  }
  if (event.key === "Escape" && !workspace.hidden) closeWorkspace();
});

function closeWorkspace() {
  workspace.hidden = true;
  workspaceContent.innerHTML = "";
}
$("#closeWorkspace").addEventListener("click", closeWorkspace);

function openWorkspace(title, markup, setup) {
  workspaceTitle.textContent = title;
  workspaceContent.innerHTML = markup;
  workspace.hidden = false;
  setup();
  workspace.scrollIntoView({ behavior: "smooth", block: "start" });
}
function textArea(label = "Enter your text") {
  return `<div><label class="field-label" for="mainText">${label}</label><textarea class="tool-textarea" id="mainText" placeholder="Start typing or paste your text here..."></textarea></div>`;
}
function copyText(value) {
  if (!value) { showToast("There is nothing to copy yet."); return; }
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(value).then(() => showToast("Copied to clipboard.")).catch(() => fallbackCopy(value));
  } else fallbackCopy(value);
}
function fallbackCopy(value) {
  const temp = document.createElement("textarea");
  temp.value = value; temp.style.position = "fixed"; temp.style.opacity = "0";
  document.body.appendChild(temp); temp.select();
  try { document.execCommand("copy"); showToast("Copied to clipboard."); }
  catch { showToast("Copy failed. Please select and copy the text manually."); }
  temp.remove();
}
function countStats(text) {
  const trimmed = text.trim();
  const words = trimmed ? trimmed.split(/\s+/u).length : 0;
  const sentences = trimmed ? (trimmed.match(/[.!?]+(?=\s|$)/g) || []).length : 0;
  return { words, chars: text.length, noSpaces: text.replace(/\s/g, "").length, sentences, reading: words ? Math.max(1, Math.ceil(words / 200)) : 0 };
}

const tools = {
  "word-counter": () => openWorkspace("Word Counter", `
    ${textArea("Text to analyze")}
    <div class="stat-grid">
      <div class="stat-box"><strong id="words">0</strong><span>Words</span></div>
      <div class="stat-box"><strong id="chars">0</strong><span>Characters</span></div>
      <div class="stat-box"><strong id="sentences">0</strong><span>Sentences</span></div>
      <div class="stat-box"><strong id="reading">0 min</strong><span>Reading time</span></div>
    </div>
    <div class="tool-actions" style="margin-top:16px"><button class="tool-button secondary" id="clearText">Clear text</button></div>`, () => {
      const input = $("#mainText");
      const update = () => { const s = countStats(input.value); $("#words").textContent=s.words; $("#chars").textContent=s.chars; $("#sentences").textContent=s.sentences; $("#reading").textContent=`${s.reading} min`; };
      input.addEventListener("input", update);
      $("#clearText").addEventListener("click", () => { input.value=""; update(); input.focus(); });
    }),
  "case-converter": () => openWorkspace("Case Converter", `
    ${textArea("Text to convert")}
    <div class="tool-actions">
      <button class="tool-button" data-case="upper">UPPERCASE</button>
      <button class="tool-button" data-case="lower">lowercase</button>
      <button class="tool-button" data-case="title">Title Case</button>
      <button class="tool-button" data-case="sentence">Sentence case</button>
      <button class="tool-button secondary" id="copyConverted">Copy result</button>
    </div>`, () => {
      const input = $("#mainText");
      $$("[data-case]").forEach(button => button.addEventListener("click", () => {
        const mode = button.dataset.case;
        const value = input.value;
        if (mode === "upper") input.value = value.toUpperCase();
        if (mode === "lower") input.value = value.toLowerCase();
        if (mode === "title") input.value = value.toLowerCase().replace(/\b([a-z])/g, c => c.toUpperCase());
        if (mode === "sentence") input.value = value.toLowerCase().replace(/(^\s*[a-z]|[.!?]\s+[a-z])/g, c => c.toUpperCase());
      }));
      $("#copyConverted").addEventListener("click", () => copyText(input.value));
    }),
  "character-counter": () => openWorkspace("Character Counter", `
    ${textArea("Text to count")}
    <div class="stat-grid">
      <div class="stat-box"><strong id="charTotal">0</strong><span>All characters</span></div>
      <div class="stat-box"><strong id="charNoSpace">0</strong><span>Without spaces</span></div>
      <div class="stat-box"><strong id="lineTotal">0</strong><span>Lines</span></div>
      <div class="stat-box"><strong id="byteTotal">0</strong><span>UTF-8 bytes</span></div>
    </div>`, () => {
      const input = $("#mainText");
      const update = () => {
        $("#charTotal").textContent = input.value.length;
        $("#charNoSpace").textContent = input.value.replace(/\s/g, "").length;
        $("#lineTotal").textContent = input.value ? input.value.split(/\r\n|\r|\n/).length : 0;
        $("#byteTotal").textContent = new TextEncoder().encode(input.value).length;
      };
      input.addEventListener("input", update);
    }),
  "percentage": () => openWorkspace("Percentage Calculator", `
    <div class="tool-form">
      <div class="tool-row">
        <div><label class="field-label" for="percentValue">Percentage (%)</label><input class="tool-input" id="percentValue" type="number" step="any" placeholder="e.g. 15"></div>
        <div><label class="field-label" for="baseValue">Number</label><input class="tool-input" id="baseValue" type="number" step="any" placeholder="e.g. 240"></div>
      </div>
      <button class="tool-button" id="calcPercent">Calculate percentage</button>
      <div class="result-panel" id="percentResult" aria-live="polite">Enter both values to calculate.</div>
      <div class="tool-row">
        <div><label class="field-label" for="partValue">Part</label><input class="tool-input" id="partValue" type="number" step="any" placeholder="e.g. 30"></div>
        <div><label class="field-label" for="wholeValue">Whole</label><input class="tool-input" id="wholeValue" type="number" step="any" placeholder="e.g. 150"></div>
      </div>
      <button class="tool-button secondary" id="calcWhatPercent">Find what percent</button>
      <div class="result-panel" id="whatPercentResult" aria-live="polite">Enter a part and a whole number.</div>
    </div>`, () => {
      const num = id => Number($(id).value);
      $("#calcPercent").addEventListener("click", () => {
        const p=$("#percentValue").value, n=$("#baseValue").value;
        if (p === "" || n === "" || !Number.isFinite(num("#percentValue")) || !Number.isFinite(num("#baseValue"))) { $("#percentResult").textContent="Please enter valid numbers in both fields."; return; }
        $("#percentResult").innerHTML = `<strong>${(num("#percentValue")*num("#baseValue")/100).toLocaleString(undefined,{maximumFractionDigits:8})}</strong> is ${num("#percentValue")}% of ${num("#baseValue")}.`;
      });
      $("#calcWhatPercent").addEventListener("click", () => {
        const p=$("#partValue").value, w=$("#wholeValue").value;
        if (p === "" || w === "" || num("#wholeValue") === 0 || !Number.isFinite(num("#partValue")) || !Number.isFinite(num("#wholeValue"))) { $("#whatPercentResult").textContent="Enter valid numbers; the whole must not be zero."; return; }
        $("#whatPercentResult").innerHTML = `<strong>${(num("#partValue")/num("#wholeValue")*100).toLocaleString(undefined,{maximumFractionDigits:8})}%</strong> — ${num("#partValue")} is this percentage of ${num("#wholeValue")}.`;
      });
    }),
  "age-calculator": () => openWorkspace("Age Calculator", `
    <div class="tool-form">
      <div><label class="field-label" for="birthDate">Date of birth</label><input class="tool-input" id="birthDate" type="date"></div>
      <div><label class="field-label" for="asOfDate">Calculate age on</label><input class="tool-input" id="asOfDate" type="date"></div>
      <button class="tool-button" id="calculateAge">Calculate age</button>
      <div class="result-panel" id="ageResult" aria-live="polite">Choose your birth date and a date to calculate age.</div>
    </div>`, () => {
      const today = new Date();
      const localDate = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
      $("#asOfDate").value = localDate(today);
      $("#birthDate").max = localDate(today);
      $("#asOfDate").addEventListener("change", () => { $("#birthDate").max = $("#asOfDate").value; });
      $("#calculateAge").addEventListener("click", () => {
        const b=$("#birthDate").value, a=$("#asOfDate").value, result=$("#ageResult");
        if (!b || !a) { result.textContent="Please select both dates."; return; }
        const [by,bm,bd]=b.split("-").map(Number), [ay,am,ad]=a.split("-").map(Number);
        const birth = new Date(by,bm-1,bd), asOf = new Date(ay,am-1,ad);
        if (birth > asOf) { result.textContent="Birth date must be on or before the calculation date."; return; }
        let years=ay-by, months=am-bm, days=ad-bd;
        if (days<0) { months--; days += new Date(ay,am-1,0).getDate(); }
        if (months<0) { years--; months+=12; }
        result.innerHTML = `Your age is <strong>${years} years, ${months} months, and ${days} days</strong>.`;
      });
    }),
  "password-generator": () => openWorkspace("Password Generator", `
    <div class="tool-form">
      <div><label class="field-label" for="passwordLength">Password length: <strong id="lengthValue">16</strong></label><input class="tool-input" id="passwordLength" type="range" min="8" max="64" value="16"></div>
      <div class="tool-row">
        <label class="field-label"><input id="includeUpper" type="checkbox" checked> Uppercase letters (A–Z)</label>
        <label class="field-label"><input id="includeLower" type="checkbox" checked> Lowercase letters (a–z)</label>
        <label class="field-label"><input id="includeNumbers" type="checkbox" checked> Numbers (0–9)</label>
        <label class="field-label"><input id="includeSymbols" type="checkbox" checked> Symbols (!@#...)</label>
      </div>
      <div class="tool-row">
        <div><label class="field-label" for="generatedPassword">Generated password</label><input class="tool-input" id="generatedPassword" readonly placeholder="Click Generate password"></div>
        <div><label class="field-label" for="passwordStrength">Character pool</label><input class="tool-input" id="passwordStrength" readonly value="Choose character types"></div>
      </div>
      <div class="tool-actions"><button class="tool-button" id="generatePassword">Generate password</button><button class="tool-button secondary" id="copyPassword">Copy password</button></div>
      <p style="color:var(--muted);font-size:11px;line-height:1.6;margin:0">Generated locally in your browser. For important accounts, use a trusted password manager and never share your password.</p>
    </div>`, () => {
      const length=$("#passwordLength");
      length.addEventListener("input",()=>$("#lengthValue").textContent=length.value);
      $("#generatePassword").addEventListener("click", () => {
        const groups = [];
        if ($("#includeUpper").checked) groups.push("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        if ($("#includeLower").checked) groups.push("abcdefghijklmnopqrstuvwxyz");
        if ($("#includeNumbers").checked) groups.push("0123456789");
        if ($("#includeSymbols").checked) groups.push("!@#$%^&*()-_=+[]{};:,.?");
        if (!groups.length) { showToast("Choose at least one character type."); return; }
        const all=groups.join("");
        const randomIndex = max => {
          const limit = Math.floor(256 / max) * max;
          const bytes = new Uint8Array(1);
          do { crypto.getRandomValues(bytes); } while (bytes[0] >= limit);
          return bytes[0] % max;
        };
        const chars = groups.map(group => group[randomIndex(group.length)]);
        while (chars.length < Number(length.value)) chars.push(all[randomIndex(all.length)]);
        for (let i=chars.length-1;i>0;i--) { const j=randomIndex(i+1); [chars[i],chars[j]]=[chars[j],chars[i]]; }
        $("#generatedPassword").value=chars.join("");
        $("#passwordStrength").value=`${all.length} possible characters`;
      });
      $("#copyPassword").addEventListener("click",()=>copyText($("#generatedPassword").value));
    })
};

$$(".open-tool").forEach(button => button.addEventListener("click", () => {
  const tool = tools[button.dataset.tool];
  if (tool) tool();
}));
